package com.product.vo;

import com.product.po.Orderinfo;

public class OrderinfoVo {
    private Orderinfo orderinfo;

	public Orderinfo getOrderinfo() {
		return orderinfo;
	}

	public void setOrderinfo(Orderinfo orderinfo) {
		this.orderinfo = orderinfo;
	}
    
    
}
