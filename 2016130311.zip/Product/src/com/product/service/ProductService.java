package com.product.service;

import com.product.po.Product;

public interface ProductService {
    public Product findById(String pid);
}
