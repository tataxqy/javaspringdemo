package com.product.service;

import com.product.po.Orderinfo;

public interface OrderinfoService {
    public void add(Orderinfo orderinfo);
}
