create database product;
use product;

SET NAMES utf8;

create table product
(
   pid                    varchar(128) not null,
   pname                  varchar(128),
   qoh                    int,
   qoh_threshold          int,
   origianal_price        float,
   discnt_rate        float,
   sid           varchar(128),
   primary key (pid)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


create table User
(
   user_id                int not null auto_increment,
   user_name                  varchar(128),
   password                    varchar(128),
   user_img          varchar(128),
   wechat         varchar(128),
   email         varchar(128),
   createtime           DATETIME,
   gender           varchar(128),
   status           int,
   type             int,
   primary key (user_id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table help
(
   id                int not null auto_increment,
   userId            int,
   title             varchar(128),
   content           text,
   time              varchar(32),
   pay               int,
   path              varchar(256),
   type              int,
   primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table orderinfo
(
   id                int not null auto_increment,
   helpId            int,
   userId             int,
   time              varchar(32),
   primary key (id)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;


